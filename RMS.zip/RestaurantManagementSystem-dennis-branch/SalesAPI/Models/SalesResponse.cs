﻿namespace SalesAPI.Models
{
    public class SalesResponse
    {
        public int statusCode { get; set; }
        public string statusMessage { get; set; }
    }
}
