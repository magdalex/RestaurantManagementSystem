﻿namespace RMSAPI.Models
{
    public class MenuItems
    {
        public int FoodID { get; set; }
        public string FoodName { get; set; }
        public float Price { get; set; }
        public int Inventory { get; set; }
    }
}
