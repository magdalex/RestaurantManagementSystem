﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RMSWPF.Models
{
    public static class GlobalValues
    {
        public static int WaiterID;
        public static float FinalPrice;

    }
}
