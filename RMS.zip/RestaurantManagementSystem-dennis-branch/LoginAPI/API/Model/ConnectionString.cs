﻿namespace API.Model
{
    public static class ConnectionString
    {
       public static string conString = @"Data Source=localhost;Initial Catalog=test_db;Integrated Security=True;TrustServerCertificate=True;MultipleActiveResultSets=True";

    }
}
