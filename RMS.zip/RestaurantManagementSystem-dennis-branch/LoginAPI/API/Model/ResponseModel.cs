﻿using API.Model;

namespace API.Model
{
    public class ResponseModel
    {

        public int statusCode { get; set; }
        public string statusMessage { get; set; }
     


    }
}
